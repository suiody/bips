<?php

namespace BitWasp\Buffertools\Exceptions;

class ParserOutOfRange extends \Exception
{
}

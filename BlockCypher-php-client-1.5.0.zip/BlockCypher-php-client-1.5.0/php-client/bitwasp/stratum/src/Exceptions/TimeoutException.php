<?php

namespace BitWasp\Stratum\Exceptions;

class TimeoutException extends \Exception
{

}

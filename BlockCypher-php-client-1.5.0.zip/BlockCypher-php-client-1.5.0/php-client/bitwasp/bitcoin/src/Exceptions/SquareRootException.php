<?php

namespace BitWasp\Bitcoin\Exceptions;

class SquareRootException extends \Exception
{

}

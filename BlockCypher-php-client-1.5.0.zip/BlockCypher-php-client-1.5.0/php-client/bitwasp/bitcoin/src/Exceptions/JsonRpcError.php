<?php
namespace BitWasp\Bitcoin\Exceptions;

class JsonRpcError extends \Exception
{

}

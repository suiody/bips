<?php

namespace BitWasp\Bitcoin\Exceptions;

class RandomBytesFailure extends \Exception
{

}

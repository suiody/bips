<?php

namespace BitWasp\Bitcoin\Exceptions;

class InvalidPrivateKey extends \Exception
{
}

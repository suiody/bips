<?php

namespace BitWasp\Bitcoin;

interface CollectionInterface extends \Countable
{

}

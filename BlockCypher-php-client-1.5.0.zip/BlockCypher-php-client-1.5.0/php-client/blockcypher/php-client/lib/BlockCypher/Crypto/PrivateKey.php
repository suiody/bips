<?php

namespace BlockCypher\Crypto;

use BitWasp\Bitcoin\Key\PrivateKeyInterface;

/**
 * Class PrivateKey
 * @package BlockCypher\Crypto
 */
interface PrivateKey extends PrivateKeyInterface
{
}